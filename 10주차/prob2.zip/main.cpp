﻿#pragma warning (disable:4996)
#define ARR_LENGTH 200
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"

/***********모든 테스트 케이스 통과***********/
int main(void)
{
	Stack stackList[ARR_LENGTH];
	int index = 0;//stackList에서 사용
	while (1) {
		printf("$ ");
		char command[ARR_LENGTH];
		int ch = 0, i = 0;
		while ((ch = getchar()) != '\n') {
			command[i++] = ch;
		}
		command[i] = '\0';

		char* first = strtok(command, " ");
		if (strcmp(first, "create") == 0) {
			char* name = strtok(NULL, " ");
			Stack stack = create(name);//stack_type을 가리킴
			stackList[index++] = stack;
			//printf("생성된 스택의 이름 : %s\n", stackList[index - 1]->name);
		}
		else if (strcmp(first, "push") == 0) {
			char* name = strtok(NULL, " ");
			char* month = strtok(NULL, " ");

			for (int i = 0; i < index; i++) {
				if (strcmp(stackList[i]->name, name) == 0) {
					push(stackList[i], month);
					break;
				}
			}
		}
		else if (strcmp(first, "pop") == 0) {
			char* name = strtok(NULL, " ");
			for (int i = 0; i < index; i++) {
				if (strcmp(stackList[i]->name, name) == 0) {
					if (!is_empty(stackList[i])) {//스택이 비어있지 않을때만 pop
						pop(stackList[i]);
						break;
					}
					else {
						printf("stack is empty\n");
						break;
					}
				}
			}
		}
		else if (strcmp(first, "list") == 0) {
			char* name = strtok(NULL, " ");
			for (int i = 0; i < index; i++) {
				if (strcmp(stackList[i]->name, name) == 0) {
					printStack(stackList[i]);
					break;
				}
			}
		}
		else if (strcmp(first, "exit") == 0) {
			return 0;
		}
	}
	return 0;
}
