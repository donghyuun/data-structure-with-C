#pragma warning (disable:4996)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"

Node* createNode(char* month);

Stack create(char* stackName) {
	Stack stack = (Stack)malloc(sizeof(struct stack_type));
	stack->name = strdup(stackName);
	stack->top = NULL;
	return stack;
}

void push(Stack stack, char* month) {
	Link newNode = (Link)malloc(sizeof(Node));
	newNode->month = strdup(month);//<--strdup �ʼ�!!!!!!!!!!!, �Ⱦ��� ��� ����� month �� ���� �ֱٿ� ����� month ������ ����� 
	newNode->next = stack->top;
	stack->top = newNode;
}

void pop(Stack stack) {
	Link oldNode = stack->top;
	stack->top = oldNode->next;
	printf("%s\n", oldNode->month);
	free(oldNode->month);
	free(oldNode);
}

bool is_empty(Stack stack) {
	if (stack->top == NULL)
		return true;
	else 
		return false;
}

void printStack(Stack stack) {
	Link head = stack->top;

	while (head != NULL) {
		printf("%s\n", head->month);
		head = head->next;
	}
}
