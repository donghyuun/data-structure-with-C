#pragma once

struct node {
	char* month;
	struct node* next;
};
typedef node Node;
typedef Node* Link;

struct stack_type {
	char* name;
	struct node* top;
};
typedef stack_type* Stack;

Stack create(char* stackName);
void push(Stack stack, char* month);
void pop(Stack stack);
bool is_empty(Stack stack);
void printStack(Stack stack);