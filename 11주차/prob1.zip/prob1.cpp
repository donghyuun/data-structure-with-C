﻿#pragma warning (disable: 4996)
#include <stdio.h>
#include "stack.h"
#define MAX 100
#define PATH 0
#define WALL 1
#define VISITED 2
#define BACKTRACKED 3

/***********모든 케이스 통과***********/

bool movable(Position pos, int dir, int caseSize);

int arr[60][60];

int main() {
	//깊이우선 탐색(DFS)
	//2자원 배열으로 방문 방법, 이중for문 사용
	//
	//이미지 픽셀 방문 시
	//(방문한 적 없는 경우)
	//스택에 픽셀 위치 push & 이미지 픽셀 방문 표시 & count++
	//8방향에 대해 갈 위치 없으면 스택에서 pop해서 왔던 위치로 돌아감
	//돌아온 위치가 제일 처음 DFS 시작한 위치인 경우 count 출력 & 초기화

	int caseNum; int count = 0;
	FILE* fp = fopen("input.txt", "r");
	if (fp == NULL) printf("fp failed");

	//케이스 갯수
	fscanf(fp, "%d", &caseNum);
	for (int i = 0; i < caseNum; i++) {//caseNum번 시행
		int caseSize = 0, count = 0;
		//픽셀의 크기
		fscanf(fp, "%d", &caseSize);//caseSize^caseSize 배열을 사용하게 됨
		//printf("caseSize: %d\n", caseSize);
		//배열에 원소들 저장
		for (int j = 0; j < caseSize; j++) {
			for (int k = 0; k < caseSize; k++) {
				fscanf(fp, "%d", &arr[j][k]);
				//printf("%d ", arr[j][k]);
			}
			//printf("\n");
		}
		//DFS 탐색
		Stack s = create();
		Position cur;//현재 위치를 나타낼 Postition 구조체
		cur.x = 0;
		cur.y = 0;

		//2차원 배열 하나하나 돌면서 검사, 이미 돌았던 원소면 다시 안돔
		for (int j = 0; j < caseSize; j++) {
			for (int k = 0; k < caseSize; k++) {
				//배열의 각 픽셀에 대해 탐색했었는지 확인 후 탐색 한적 없다면 DFS 시작
				//탐색할 수 있는 픽셀이 아닌 경우(방문했었거나, 벽, 외부인 경우) => 그다음 픽셀로 넘어감
				if (arr[j][k] != 1) continue;
				else {
					cur.x = j; cur.y = k;
					count = 1;
				}
				//탐색할 수 있는 경우=> 해당 노드로 이동 후, cur변경
				//printf("arr[%d][%d] == 1\n", j, k);
				while (1) {
					arr[cur.x][cur.y] = VISITED;
					bool forwarded = false;
					for (int dir = 0; dir < 8; dir++) {
						//printf("dir: %d\n", dir);
						if (movable(cur, dir, caseSize)) {
							//printf("이동할 수 있는 경로 존재, 현재 위치 스택 삽입: %d %d\n", cur.x, cur.y);
							push(s, cur);
							cur = move_to(cur, dir);
							forwarded = true;
							count++;
							break;
						}
					}
					if (!forwarded) {
						arr[cur.x][cur.y] = BACKTRACKED;
						if (is_empty(s)) { printf("%d ", count); break; }
						cur = pop(s);
						//printf("경로 더 이상 없으므로 이전 위치로 되돌아감: (%d %d)\n", cur.x, cur.y);
					}
				}
			}
		}
		printf("\n");
	}
	return 0;
}

bool movable(Position cur, int dir, int caseSize) {
	//dir 0이면 북, 1이면 동북 , 2면 동, 3이면 동남, 4면 남, 5면 남서, 6이면 서, 7이면 북서
	//북
	if (dir == 0) {
		if (arr[cur.x - 1][cur.y] == 1)return true;
		else return false;
	}
	//동북
	else if (dir == 1) {
		if(arr[cur.x-1][cur.y+1] == 1)return true;
		else return false;
	}
	//동
	else if (dir == 2) {
		if(arr[cur.x][cur.y+1] == 1)return true;
		else return false;

	}
	// 동남
	else if (dir == 3) {
		if(arr[cur.x+1][cur.y+1] == 1)return true;
		else return false;
	}
	//남
	else if (dir == 4) {
		if(arr[cur.x+1][cur.y] == 1)return true;
		else return false;
	}
	//남서
	else if (dir == 5) {
		if(arr[cur.x+1][cur.y-1] == 1)return true;
		else return false;
	}
	//서
	else if (dir == 6) {
		if(arr[cur.x][cur.y-1] == 1)return true;
		else return false;
	}
	//북서
	else if (dir == 7) {
		if(arr[cur.x-1][cur.y-1] == 1)return true;
		else return false;
	}
}