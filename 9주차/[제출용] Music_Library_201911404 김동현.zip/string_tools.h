#ifndef STRING_TOOLS_H
#define STRING_TOOLS_H

#include <stdio.h>

int read_line(FILE* fp, char str[], int n);

#endif